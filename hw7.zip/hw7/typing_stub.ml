exception NotImplemented
exception TypingError

(* tprogram : Ast.program -> Core.program *)
let tprogram (dlist, exp) = raise NotImplemented
