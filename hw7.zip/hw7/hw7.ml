open Test;;

let _ = TestAll.test "test.tml";;

(* let _ = TestTranslate.test MonoSample.s1;; *)
